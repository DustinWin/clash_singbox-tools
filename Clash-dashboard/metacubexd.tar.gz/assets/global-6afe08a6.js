import{a7 as a}from"./vendor-e771adde.js";import{a4 as m}from"./index-267c6abf.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
