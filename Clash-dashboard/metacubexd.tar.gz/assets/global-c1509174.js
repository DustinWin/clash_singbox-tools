import{Y as a}from"./vendor-5507c805.js";import{ac as m}from"./index-6a079fcf.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
