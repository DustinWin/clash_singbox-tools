import{a6 as a}from"./vendor-deac668d.js";import{a4 as r}from"./index-2096cdf8.js";const s=o=>a(o).locale(r()).fromNow();export{s as f};
