import{Y as a}from"./vendor-97ea48b2.js";import{a8 as m}from"./index-900f431a.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
