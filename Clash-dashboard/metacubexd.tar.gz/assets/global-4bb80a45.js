import{_ as a}from"./vendor-246dca1c.js";import{a8 as m}from"./index-3f2662a6.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
