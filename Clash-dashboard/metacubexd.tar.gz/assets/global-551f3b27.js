import{_ as a}from"./vendor-ec1fbc1a.js";import{a8 as m}from"./index-2e76e9da.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
